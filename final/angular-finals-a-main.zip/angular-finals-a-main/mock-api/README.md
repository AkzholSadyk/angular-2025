# Final Task — Variant A (Tickets) Mock API

DO NOT CHANGE ANYTHING IN HERE

## Rules

- Run npm commands **ONLY** in **ROOT** directory
- Do your work **ONLY** in: `frontend/`
