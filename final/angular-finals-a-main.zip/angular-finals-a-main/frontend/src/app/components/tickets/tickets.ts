// src/app/pages/tickets/tickets.page.ts
import { CommonModule } from '@angular/common';
import { Component, DestroyRef, inject } from '@angular/core';
import { Router, ActivatedRoute, RouterLink } from '@angular/router';
import { FormControl, ReactiveFormsModule } from '@angular/forms';
import {
  debounceTime,
  distinctUntilChanged,
  map,
  shareReplay,
  startWith,
  switchMap,
  combineLatest,
} from 'rxjs';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { TicketsApiService } from '../../api/tickets-api.service';
import { TicketStatus } from '../../models/ticket.model';

type FilterStatus = TicketStatus & 'all';

const DEFAULTS = {
  page: 1,
  limit: 10,
  status: 'all' as FilterStatus,
  q: '',
};

function asInt(v: string | null, fallback: number) {
  const n = Number(v);
  return Number.isFinite(n) && n > 0 ? n : fallback;
}

type PageBtn = { type: 'page'; key: string; value: number } | { type: 'dots'; key: string };

@Component({
  standalone: true,
  imports: [CommonModule, RouterLink, ReactiveFormsModule],
  selector: 'app-tickets-page',
  templateUrl: './tickets.html',
  styleUrl: './tickets.css',
})
export class Tickets {
  private api = inject(TicketsApiService);
  private router = inject(Router);
  private route = inject(ActivatedRoute);
  private destroyRef = inject(DestroyRef);

  // UI controls
  qCtrl = new FormControl('', { nonNullable: true });
  statusCtrl = new FormControl<FilterStatus>('all' as FilterStatus, { nonNullable: true });

  // read query params -> normalized state
  private qp$ = this.route.queryParamMap.pipe(
    map((p) => ({
      page: asInt(p.get('page'), DEFAULTS.page),
      limit: asInt(p.get('limit'), DEFAULTS.limit),
      status: p.get('status') as FilterStatus,
      q: (p.get('q') ?? DEFAULTS.q).trim(),
    })),
    distinctUntilChanged((a, b) => JSON.stringify(a) === JSON.stringify(b)),
    shareReplay({ bufferSize: 1, refCount: true })
  );

  constructor() {
    this.qp$.pipe(takeUntilDestroyed(this.destroyRef)).subscribe(({ q, status }) => {
      if (this.qCtrl.value !== q) this.qCtrl.setValue(q, { emitEvent: false });
      if (this.statusCtrl.value !== status) this.statusCtrl.setValue(status, { emitEvent: false });
    });

    const q$ = this.qCtrl.valueChanges.pipe(
      startWith(this.qCtrl.value),
      debounceTime(300),
      map((v) => v.trim()),
      distinctUntilChanged()
    );

    const status$ = this.statusCtrl.valueChanges.pipe(
      startWith(this.statusCtrl.value),
      distinctUntilChanged()
    );

    combineLatest([q$, status$])
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe(([q, status]) => {
        this.setQuery({
          q: q ?? undefined,
          status: status ?? undefined,
          page: 1,
        });
      });
  }

  res$ = this.qp$.pipe(
    switchMap(({ page, limit, status, q }) => this.api.getTickets({ page, limit, status, q })),
    shareReplay({ bufferSize: 1, refCount: true })
  );

  setPage(page: number) {
    this.qp$.pipe(takeUntilDestroyed(this.destroyRef), startWith(null as any)).subscribe(); // no-op safeguard
    this.setQuery({ page });
  }

  goPrev(page: number) {
    if (page > 1) this.setQuery({ page: page - 1 });
  }

  pageButtons(page: number, total: number): PageBtn[] {
    if (total <= 1) return [];

    const addPage = (arr: PageBtn[], v: number) =>
      arr.push({ type: 'page', key: `p${v}`, value: v });

    const addDots = (arr: PageBtn[], k: string) => arr.push({ type: 'dots', key: `d${k}` });

    const out: PageBtn[] = [];
    const clamp = (v: number) => Math.max(1, Math.min(total, v));

    const core = new Set<number>([1, 2, total - 1, total, clamp(page - 1), page, clamp(page + 1)]);

    const pages = Array.from(core)
      .filter((n) => n >= 1 && n <= total)
      .sort((a, b) => a - b);

    let prev = 0;
    for (const p of pages) {
      if (prev && p - prev > 1) addDots(out, `${prev}_${p}`);
      addPage(out, p);
      prev = p;
    }
    return out;
  }
  goNext(page: number, totalPages: number) {
    if (page < totalPages) this.setQuery({ page: page + 1 });
  }

  private setQuery(
    partial: Partial<{ page: number; limit: number; status: FilterStatus; q: string }>
  ) {
    const cur = this.route.snapshot.queryParamMap;
    const merged = {
      page: asInt(cur.get('page'), DEFAULTS.page),
      limit: asInt(cur.get('limit'), DEFAULTS.limit),
      status: (cur.get('status') as FilterStatus) || '',
      q: (cur.get('q') ?? DEFAULTS.q).trim(),
      ...partial,
    };

    this.router.navigate([], {
      relativeTo: this.route,
      queryParams: merged,
      queryParamsHandling: '', // replace
    });
  }
}
