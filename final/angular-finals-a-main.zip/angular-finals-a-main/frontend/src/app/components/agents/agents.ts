import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TicketsApiService } from '../../api/tickets-api.service';

@Component({
  standalone: true,
  imports: [CommonModule],
  selector: 'app-agents-page',
  templateUrl: './agents.html',
  styleUrl: './agents.css',
})
export class Agents {
  private api = inject(TicketsApiService);
  agents$ = this.api.getAgents();

  initials(name: string): string {
    const parts = (name || '').trim().split(/\s+/).filter(Boolean);
    const a = parts[0]?.[0] ?? '?';
    const b = parts.length > 1 ? parts[parts.length - 1][0] : '';
    return (a + b).toUpperCase();
  }

  avatarBg(seed: string): string {
    // deterministic hue from id
    let hash = 0;
    for (let i = 0; i < seed.length; i++) hash = (hash * 31 + seed.charCodeAt(i)) | 0;
    const hue = Math.abs(hash) % 360;
    return `hsl(${hue} 70% 45%)`;
  }
}
