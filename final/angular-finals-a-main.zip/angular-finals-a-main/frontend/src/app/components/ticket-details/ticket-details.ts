import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute } from '@angular/router';
import { map } from 'rxjs/operators';

@Component({
  standalone: true,
  imports: [CommonModule],
  selector: 'app-ticket-details',
  templateUrl: './ticket-details.html',
  styleUrl: './ticket-details.css',
})
export class TicketDetails {
  private route = inject(ActivatedRoute);

  id$ = this.route.paramMap.pipe(map((p) => p.get('id') || ''));
  constructor() {}
}
