import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Agent } from '../models/agent.model';
import { TicketsListResponse } from '../models/ticket.model';

@Injectable({ providedIn: 'root' })
export class TicketsApiService {
  private http = inject(HttpClient);
  private baseUrl = '/api';

  getAgents(): Observable<Agent[]> {
    return this.http.get<Agent[]>(`${this.baseUrl}/agents`);
  }

  getTickets(params: {
    page?: number;
    limit?: number;
    status?: string;
    priority?: string;
    agentId?: string;
    q?: string;
  }): Observable<TicketsListResponse> {
    let httpParams = new HttpParams();
    Object.entries(params).forEach(([k, v]) => {
      if (v === undefined || v === null || v === '') return;
      httpParams = httpParams.set(k, String(v));
    });

    return this.http.get<TicketsListResponse>(`${this.baseUrl}/tickets`, {
      params: httpParams,
    });
  }
}
