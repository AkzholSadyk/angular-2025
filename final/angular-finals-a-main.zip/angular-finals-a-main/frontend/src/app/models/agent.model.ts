export interface Agent {
  id: string;
  name: string;
  role: string;
  avatarUrl?: string;
}
