# Final Task — Variant A (Tickets) Frontend

Do your tasks here

## Instructions are given in the root folder

Run npm commands **ONLY** in **ROOT** directory
